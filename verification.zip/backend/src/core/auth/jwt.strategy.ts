import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { JwtPayload } from '../types/tenant.types';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET as string,
    });
  }

  async validate(payload: JwtPayload & { purpose?: string }) {
    if (payload.purpose === 'totp_pending') {
      throw new UnauthorizedException('Token temporaire invalide pour cette route.');
    }

    if (!payload.sub || !payload.tenantId) {
      throw new UnauthorizedException('Token invalide ou incomplet.');
    }

    return {
      userId: payload.sub,
      tenantId: payload.tenantId,
      sectorType: payload.sectorType,
      roles: payload.roles,
      permissions: payload.permissions,
      tenantCode: payload.tenantCode,
      mustChangePassword: payload.mustChangePassword,
    };
  }

}
